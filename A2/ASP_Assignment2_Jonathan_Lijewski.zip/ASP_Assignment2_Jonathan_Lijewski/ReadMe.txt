This assignment was completed using a single .cpp file, where the mapper and reducer logic was combined together into the single combiner file.

To Run:

make

./combiner numOfSlots numOfReducers < inputFile > outputFile


